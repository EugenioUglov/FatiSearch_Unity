﻿namespace Alturos.Yolo
{
    public enum DetectionSystem
    {
        Unknown,
        CPU,
        GPU
    }
}
