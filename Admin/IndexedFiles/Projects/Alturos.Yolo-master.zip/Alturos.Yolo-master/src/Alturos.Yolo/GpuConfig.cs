﻿namespace Alturos.Yolo
{
    public class GpuConfig
    {
        public int GpuIndex { get; set; }
    }
}
